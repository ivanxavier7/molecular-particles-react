# Ivan Xavier Portfolio


Integrar spline mais tarde:
* [Spline](https://www.youtube.com/watch?v=EJxeMbDTkVI&t=23s)


Resources:
* [Unsplash](https://unsplash.com/pt-br)
* [Google Fonts](https://fonts.google.com/)



``` bash
npm install
npm run dev
```

[Particles Video 1:00:00](https://www.youtube.com/watch?v=qp0-L_M3Ad4&t=136s)